import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import { getDb } from './server/db.js';
import { authMiddleware } from './server/auth.js';
import { apiRouter } from './server/api.js';
import { startNotificationWorker } from './server/worker.js';

async function bootstrap() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const isProd = process.env.NODE_ENV === 'production';

  // Initialize SQLite database
  await getDb();
  console.log('[Database] SQLite initialized with seed data.');

  // Start background worker for notifications & reminders
  startNotificationWorker();

  // Middleware
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));
  app.use(cookieParser());
  app.use(cors());

  // Attach auth session middleware
  app.use(authMiddleware);

  // Mount API router
  app.use('/api', apiRouter);

  // Vite Integration
  if (isProd) {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[STUDY] VIP Academy Management System running on http://0.0.0.0:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error('[STUDY] Fatal server startup error:', err);
  process.exit(1);
});
